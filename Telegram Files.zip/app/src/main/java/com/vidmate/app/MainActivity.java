package com.vidmate.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.vidmate.app.adapter.CategoryAdapter;
import com.vidmate.app.adapter.VideoAdapter;
import com.vidmate.app.model.SearchResponse;
import com.vidmate.app.model.VideoItem;
import com.vidmate.app.network.RetrofitClient;
import com.vidmate.app.network.YouTubeApiService;
import com.vidmate.app.utils.PreferenceManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private RecyclerView categoryRecycler;
    private RecyclerView videoRecycler;
    private SwipeRefreshLayout swipeRefresh;
    private ProgressBar progressBar;
    private EditText searchEdit;
    private ImageButton searchButton;
    private BottomNavigationView bottomNav;

    private CategoryAdapter categoryAdapter;
    private VideoAdapter videoAdapter;
    private YouTubeApiService apiService;
    private PreferenceManager prefs;

    private List<String> categories;
    private String currentQuery = "";
    private String nextPageToken = null;
    private boolean isLoading = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new PreferenceManager(this);
        apiService = RetrofitClient.getApiService();

        initViews();
        setupCategoryRecycler();
        setupVideoRecycler();
        setupBottomNavigation();
        setupSearch();

        loadTrendingVideos();
    }

    private void initViews() {
        categoryRecycler = findViewById(R.id.categoryRecycler);
        videoRecycler = findViewById(R.id.videoRecycler);
        swipeRefresh = findViewById(R.id.swipeRefresh);
        progressBar = findViewById(R.id.progressBar);
        searchEdit = findViewById(R.id.searchEdit);
        searchButton = findViewById(R.id.searchButton);
        bottomNav = findViewById(R.id.bottomNavigation);

        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            public void onRefresh() {
                refreshVideos();
            }
        });
    }

    private void setupCategoryRecycler() {
        categories = Arrays.asList(
            "All", "Music", "Gaming", "Movies", "News", "Sports", 
            "Technology", "Comedy", "Education", "Entertainment"
        );

        categoryAdapter = new CategoryAdapter(this);
        categoryAdapter.setCategories(categories);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        categoryRecycler.setLayoutManager(layoutManager);
        categoryRecycler.setAdapter(categoryAdapter);

        categoryAdapter.setOnCategoryClickListener(new CategoryAdapter.OnCategoryClickListener() {
            public void onCategoryClick(String category, int position) {
                if (position == 0) {
                    loadTrendingVideos();
                } else {
                    searchVideos(category);
                }
            }
        });
    }

    private void setupVideoRecycler() {
        videoAdapter = new VideoAdapter(this);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        videoRecycler.setLayoutManager(layoutManager);
        videoRecycler.setAdapter(videoAdapter);

        // Infinite scroll
        videoRecycler.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager lm = (LinearLayoutManager) recyclerView.getLayoutManager();
                int visibleItemCount = lm.getChildCount();
                int totalItemCount = lm.getItemCount();
                int firstVisibleItem = lm.findFirstVisibleItemPosition();

                if (!isLoading && nextPageToken != null) {
                    if ((visibleItemCount + firstVisibleItem) >= totalItemCount - 5) {
                        loadMoreVideos();
                    }
                }
            }
        });

        videoAdapter.setOnVideoClickListener(new VideoAdapter.OnVideoClickListener() {
            public void onVideoClick(VideoItem video, int position) {
                openPlayer(video);
            }
        });

        videoAdapter.setOnVideoLongClickListener(new VideoAdapter.OnVideoLongClickListener() {
            public void onVideoLongClick(VideoItem video, int position) {
                showDownloadOptions(video);
            }
        });
    }

    private void setupBottomNavigation() {
        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            public boolean onNavigationItemSelected(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.nav_home) {
                    loadTrendingVideos();
                    return true;
                } else if (id == R.id.nav_trending) {
                    startActivity(new Intent(MainActivity.this, TrendingActivity.class));
                    return true;
                } else if (id == R.id.nav_downloads) {
                    startActivity(new Intent(MainActivity.this, DownloadsActivity.class));
                    return true;
                } else if (id == R.id.nav_library) {
                    startActivity(new Intent(MainActivity.this, HistoryActivity.class));
                    return true;
                }
                return false;
            }
        });
    }

    private void setupSearch() {
        searchButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String query = searchEdit.getText().toString().trim();
                if (!query.isEmpty()) {
                    searchVideos(query);
                }
            }
        });

        searchEdit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
            }
        });
    }

    private void loadTrendingVideos() {
        showLoading(true);
        currentQuery = "";
        nextPageToken = null;

        Call<SearchResponse> call = apiService.getTrendingVideos(
            "snippet", "", "video", "viewCount", 25, Constants.YOUTUBE_API_KEY
        );

        call.enqueue(new Callback<SearchResponse>() {
            public void onResponse(Call<SearchResponse> call, Response<SearchResponse> response) {
                showLoading(false);
                if (response.isSuccessful() && response.body() != null) {
                    List<VideoItem> videos = parseSearchResults(response.body());
                    videoAdapter.setVideos(videos);
                    nextPageToken = response.body().getNextPageToken();
                }
            }

            public void onFailure(Call<SearchResponse> call, Throwable t) {
                showLoading(false);
                Toast.makeText(MainActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void searchVideos(String query) {
        showLoading(true);
        currentQuery = query;
        nextPageToken = null;

        Call<SearchResponse> call = apiService.searchVideosSimple(
            "snippet", query, "video", 25, Constants.YOUTUBE_API_KEY
        );

        call.enqueue(new Callback<SearchResponse>() {
            public void onResponse(Call<SearchResponse> call, Response<SearchResponse> response) {
                showLoading(false);
                if (response.isSuccessful() && response.body() != null) {
                    List<VideoItem> videos = parseSearchResults(response.body());
                    videoAdapter.setVideos(videos);
                    nextPageToken = response.body().getNextPageToken();
                }
            }

            public void onFailure(Call<SearchResponse> call, Throwable t) {
                showLoading(false);
                Toast.makeText(MainActivity.this, "Search failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadMoreVideos() {
        if (isLoading || nextPageToken == null) return;
        isLoading = true;

        Call<SearchResponse> call;
        if (currentQuery.isEmpty()) {
            call = apiService.getTrendingVideos(
                "snippet", "", "video", "viewCount", 25, Constants.YOUTUBE_API_KEY
            );
        } else {
            call = apiService.searchVideos(
                "snippet", currentQuery, "video", 25, Constants.YOUTUBE_API_KEY, nextPageToken
            );
        }

        call.enqueue(new Callback<SearchResponse>() {
            public void onResponse(Call<SearchResponse> call, Response<SearchResponse> response) {
                isLoading = false;
                if (response.isSuccessful() && response.body() != null) {
                    List<VideoItem> videos = parseSearchResults(response.body());
                    videoAdapter.addVideos(videos);
                    nextPageToken = response.body().getNextPageToken();
                }
            }

            public void onFailure(Call<SearchResponse> call, Throwable t) {
                isLoading = false;
            }
        });
    }

    private void refreshVideos() {
        nextPageToken = null;
        if (currentQuery.isEmpty()) {
            loadTrendingVideos();
        } else {
            searchVideos(currentQuery);
        }
        swipeRefresh.setRefreshing(false);
    }

    private List<VideoItem> parseSearchResults(SearchResponse response) {
        List<VideoItem> videos = new ArrayList<VideoItem>();

        if (response.getItems() == null) return videos;

        for (int i = 0; i < response.getItems().size(); i++) {
            SearchResponse.SearchItem item = response.getItems().get(i);
            if (item.getId() == null || item.getId().getVideoId() == null) continue;

            VideoItem video = new VideoItem();
            video.setVideoId(item.getId().getVideoId());

            if (item.getSnippet() != null) {
                video.setTitle(item.getSnippet().getTitle());
                video.setDescription(item.getSnippet().getDescription());
                video.setChannelTitle(item.getSnippet().getChannelTitle());
                video.setChannelId(item.getSnippet().getChannelId());
                video.setPublishedAt(item.getSnippet().getPublishedAt());

                if (item.getSnippet().getThumbnails() != null) {
                    SearchResponse.Thumbnails thumbs = item.getSnippet().getThumbnails();
                    if (thumbs.getHigh() != null) {
                        video.setThumbnailUrl(thumbs.getHigh().getUrl());
                    } else if (thumbs.getMedium() != null) {
                        video.setThumbnailUrl(thumbs.getMedium().getUrl());
                    } else if (thumbs.getDefaultThumbnail() != null) {
                        video.setThumbnailUrl(thumbs.getDefaultThumbnail().getUrl());
                    }
                }
            }

            videos.add(video);
        }

        return videos;
    }

    private void openPlayer(VideoItem video) {
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra(Constants.EXTRA_VIDEO_ID, video.getVideoId());
        intent.putExtra(Constants.EXTRA_VIDEO_TITLE, video.getTitle());
        intent.putExtra(Constants.EXTRA_VIDEO_THUMB, video.getBestThumbnail());
        intent.putExtra(Constants.EXTRA_CHANNEL_NAME, video.getChannelTitle());
        startActivity(intent);
    }

    private void showDownloadOptions(VideoItem video) {
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra(Constants.EXTRA_VIDEO_ID, video.getVideoId());
        intent.putExtra(Constants.EXTRA_VIDEO_TITLE, video.getTitle());
        intent.putExtra(Constants.EXTRA_VIDEO_THUMB, video.getBestThumbnail());
        intent.putExtra("show_download", true);
        startActivity(intent);
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
