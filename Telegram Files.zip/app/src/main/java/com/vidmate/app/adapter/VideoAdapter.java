package com.vidmate.app.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.vidmate.app.Constants;
import com.vidmate.app.PlayerActivity;
import com.vidmate.app.R;
import com.vidmate.app.model.VideoItem;
import com.vidmate.app.utils.Utils;
import java.util.ArrayList;
import java.util.List;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.ViewHolder> {

    private Context context;
    private List<VideoItem> videos;
    private OnVideoClickListener clickListener;
    private OnVideoLongClickListener longClickListener;

    public interface OnVideoClickListener {
        void onVideoClick(VideoItem video, int position);
    }

    public interface OnVideoLongClickListener {
        void onVideoLongClick(VideoItem video, int position);
    }

    public VideoAdapter(Context context) {
        this.context = context;
        this.videos = new ArrayList<VideoItem>();
    }

    public void setOnVideoClickListener(OnVideoClickListener listener) {
        this.clickListener = listener;
    }

    public void setOnVideoLongClickListener(OnVideoLongClickListener listener) {
        this.longClickListener = listener;
    }

    public void setVideos(List<VideoItem> videos) {
        this.videos = videos;
        notifyDataSetChanged();
    }

    public void addVideos(List<VideoItem> newVideos) {
        int startPosition = videos.size();
        videos.addAll(newVideos);
        notifyItemRangeInserted(startPosition, newVideos.size());
    }

    public List<VideoItem> getVideos() {
        return videos;
    }

    public void clear() {
        videos.clear();
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_video, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final VideoItem video = videos.get(position);

        holder.titleText.setText(video.getTitle());
        holder.channelText.setText(video.getChannelTitle());

        String info = "";
        if (video.getViewCount() > 0) {
            info = Utils.formatViews(video.getViewCount()) + " views";
        }
        if (video.getPublishedAt() != null) {
            if (!info.isEmpty()) info += " • ";
            info += Utils.formatTimeAgo(video.getPublishedAt());
        }
        holder.infoText.setText(info);

        // Duration badge
        if (video.getDuration() != null && !video.getDuration().isEmpty()) {
            holder.durationText.setVisibility(View.VISIBLE);
            holder.durationText.setText(Utils.formatDuration(video.getDuration()));
        } else {
            holder.durationText.setVisibility(View.GONE);
        }

        // Load thumbnail
        Glide.with(context)
            .load(video.getBestThumbnail())
            .placeholder(R.drawable.thumbnail_placeholder)
            .error(R.drawable.thumbnail_placeholder)
            .centerCrop()
            .into(holder.thumbnailImage);

        // Click listener
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (clickListener != null) {
                    clickListener.onVideoClick(video, position);
                } else {
                    Intent intent = new Intent(context, PlayerActivity.class);
                    intent.putExtra(Constants.EXTRA_VIDEO_ID, video.getVideoId());
                    intent.putExtra(Constants.EXTRA_VIDEO_TITLE, video.getTitle());
                    intent.putExtra(Constants.EXTRA_VIDEO_THUMB, video.getBestThumbnail());
                    intent.putExtra(Constants.EXTRA_CHANNEL_NAME, video.getChannelTitle());
                    context.startActivity(intent);
                }
            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                if (longClickListener != null) {
                    longClickListener.onVideoLongClick(video, position);
                }
                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return videos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView thumbnailImage;
        ImageView channelImage;
        TextView titleText;
        TextView channelText;
        TextView infoText;
        TextView durationText;

        public ViewHolder(View itemView) {
            super(itemView);
            thumbnailImage = itemView.findViewById(R.id.thumbnailImage);
            channelImage = itemView.findViewById(R.id.channelImage);
            titleText = itemView.findViewById(R.id.titleText);
            channelText = itemView.findViewById(R.id.channelText);
            infoText = itemView.findViewById(R.id.infoText);
            durationText = itemView.findViewById(R.id.durationText);
        }
    }
}
