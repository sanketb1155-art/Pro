package com.vidmate.app.model;

import java.io.Serializable;

public class DownloadItem implements Serializable {
    public static final int STATUS_PENDING = 0;
    public static final int STATUS_DOWNLOADING = 1;
    public static final int STATUS_PAUSED = 2;
    public static final int STATUS_COMPLETED = 3;
    public static final int STATUS_FAILED = 4;

    private String id;
    private String videoId;
    private String title;
    private String thumbnailUrl;
    private String quality;
    private String format;
    private String downloadUrl;
    private String filePath;
    private long totalSize;
    private long downloadedSize;
    private int status;
    private long timestamp;

    public DownloadItem() {
        this.timestamp = System.currentTimeMillis();
        this.status = STATUS_PENDING;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getVideoId() { return videoId; }
    public void setVideoId(String videoId) { this.videoId = videoId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getThumbnailUrl() { return thumbnailUrl; }
    public void setThumbnailUrl(String thumbnailUrl) { this.thumbnailUrl = thumbnailUrl; }

    public String getQuality() { return quality; }
    public void setQuality(String quality) { this.quality = quality; }

    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format; }

    public String getDownloadUrl() { return downloadUrl; }
    public void setDownloadUrl(String downloadUrl) { this.downloadUrl = downloadUrl; }

    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }

    public long getTotalSize() { return totalSize; }
    public void setTotalSize(long totalSize) { this.totalSize = totalSize; }

    public long getDownloadedSize() { return downloadedSize; }
    public void setDownloadedSize(long downloadedSize) { this.downloadedSize = downloadedSize; }

    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    public int getProgress() {
        if (totalSize > 0) {
            return (int) ((downloadedSize * 100) / totalSize);
        }
        return 0;
    }

    public String getStatusText() {
        switch (status) {
            case STATUS_PENDING: return "Pending";
            case STATUS_DOWNLOADING: return "Downloading";
            case STATUS_PAUSED: return "Paused";
            case STATUS_COMPLETED: return "Completed";
            case STATUS_FAILED: return "Failed";
            default: return "Unknown";
        }
    }
}
