package com.vidmate.app.utils;

import android.content.Context;
import android.content.SharedPreferences;
import com.vidmate.app.model.DownloadItem;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class PreferenceManager {

    private static final String PREF_NAME = "VidMatePrefs";
    private static final String KEY_DOWNLOADS = "downloads";
    private static final String KEY_HISTORY = "history";
    private static final String KEY_DARK_MODE = "dark_mode";
    private static final String KEY_QUALITY = "default_quality";
    private static final String KEY_FORMAT = "default_format";
    private static final String KEY_WIFI_ONLY = "wifi_only";
    private static final String KEY_CONCURRENT = "concurrent_downloads";

    private SharedPreferences prefs;
    private Gson gson;

    public PreferenceManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    public void saveDownloads(List<DownloadItem> downloads) {
        String json = gson.toJson(downloads);
        prefs.edit().putString(KEY_DOWNLOADS, json).apply();
    }

    public List<DownloadItem> getDownloads() {
        String json = prefs.getString(KEY_DOWNLOADS, null);
        if (json == null) {
            return new ArrayList<DownloadItem>();
        }
        Type type = new TypeToken<List<DownloadItem>>(){}.getType();
        return gson.fromJson(json, type);
    }

    public void saveHistory(List<VideoItem> history) {
        String json = gson.toJson(history);
        prefs.edit().putString(KEY_HISTORY, json).apply();
    }

    public List<VideoItem> getHistory() {
        String json = prefs.getString(KEY_HISTORY, null);
        if (json == null) {
            return new ArrayList<VideoItem>();
        }
        Type type = new TypeToken<List<VideoItem>>(){}.getType();
        return gson.fromJson(json, type);
    }

    public void setDarkMode(boolean enabled) {
        prefs.edit().putBoolean(KEY_DARK_MODE, enabled).apply();
    }

    public boolean isDarkMode() {
        return prefs.getBoolean(KEY_DARK_MODE, false);
    }

    public void setDefaultQuality(String quality) {
        prefs.edit().putString(KEY_QUALITY, quality).apply();
    }

    public String getDefaultQuality() {
        return prefs.getString(KEY_QUALITY, "720p");
    }

    public void setDefaultFormat(String format) {
        prefs.edit().putString(KEY_FORMAT, format).apply();
    }

    public String getDefaultFormat() {
        return prefs.getString(KEY_FORMAT, "MP4");
    }

    public void setWifiOnly(boolean enabled) {
        prefs.edit().putBoolean(KEY_WIFI_ONLY, enabled).apply();
    }

    public boolean isWifiOnly() {
        return prefs.getBoolean(KEY_WIFI_ONLY, false);
    }

    public void setConcurrentDownloads(int count) {
        prefs.edit().putInt(KEY_CONCURRENT, count).apply();
    }

    public int getConcurrentDownloads() {
        return prefs.getInt(KEY_CONCURRENT, 3);
    }
}
