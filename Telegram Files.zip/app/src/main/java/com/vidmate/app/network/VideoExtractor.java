package com.vidmate.app.network;

import android.os.AsyncTask;
import com.vidmate.app.model.VideoItem;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class VideoExtractor {

    public interface ExtractCallback {
        void onSuccess(List<VideoStream> streams);
        void onError(String error);
    }

    public static class VideoStream {
        private String url;
        private String quality;
        private String format;
        private String type;
        private long size;

        public VideoStream(String url, String quality, String format, String type) {
            this.url = url;
            this.quality = quality;
            this.format = format;
            this.type = type;
        }

        public String getUrl() { return url; }
        public void setUrl(String url) { this.url = url; }

        public String getQuality() { return quality; }
        public void setQuality(String quality) { this.quality = quality; }

        public String getFormat() { return format; }
        public void setFormat(String format) { this.format = format; }

        public String getType() { return type; }
        public void setType(String type) { this.type = type; }

        public long getSize() { return size; }
        public void setSize(long size) { this.size = size; }
    }

    public void extractVideo(String videoId, final ExtractCallback callback) {
        new AsyncTask<String, Void, List<VideoStream>>() {
            private String error = null;

            @Override
            protected List<VideoStream> doInBackground(String... params) {
                try {
                    String videoId = params[0];
                    return extractFromInvidious(videoId);
                } catch (Exception e) {
                    error = e.getMessage();
                    return null;
                }
            }

            @Override
            protected void onPostExecute(List<VideoStream> streams) {
                if (error != null) {
                    callback.onError(error);
                } else if (streams != null) {
                    callback.onSuccess(streams);
                } else {
                    callback.onError("Failed to extract video");
                }
            }
        }.execute(videoId);
    }

    private List<VideoStream> extractFromInvidious(String videoId) throws Exception {
        List<VideoStream> streams = new ArrayList<VideoStream>();

        // Try multiple invidious instances
        String[] instances = {
            "https://vid.puffyan.us",
            "https://y.com.sb",
            "https://invidious.snopyta.org",
            "https://invidious.kavin.rocks"
        };

        for (int i = 0; i < instances.length; i++) {
            try {
                String apiUrl = instances[i] + "/api/v1/videos/" + videoId;
                String response = makeHttpRequest(apiUrl);

                JSONObject json = new JSONObject(response);

                if (json.has("formatStreams")) {
                    JSONArray formatStreams = json.getJSONArray("formatStreams");
                    for (int j = 0; j < formatStreams.length(); j++) {
                        JSONObject stream = formatStreams.getJSONObject(j);
                        String url = stream.getString("url");
                        String quality = stream.optString("qualityLabel", "Unknown");
                        String type = stream.optString("type", "video/mp4");
                        String format = type.contains("audio") ? "audio" : "video";

                        streams.add(new VideoStream(url, quality, format, type));
                    }
                }

                if (json.has("adaptiveFormats")) {
                    JSONArray adaptiveFormats = json.getJSONArray("adaptiveFormats");
                    for (int j = 0; j < adaptiveFormats.length(); j++) {
                        JSONObject stream = adaptiveFormats.getJSONObject(j);
                        String url = stream.getString("url");
                        String quality = stream.optString("qualityLabel", stream.optString("quality", "Unknown"));
                        String type = stream.optString("type", "video/mp4");
                        String format = type.contains("audio") ? "audio" : "video";

                        streams.add(new VideoStream(url, quality, format, type));
                    }
                }

                if (streams.size() > 0) {
                    break;
                }
            } catch (Exception e) {
                continue;
            }
        }

        return streams;
    }

    private String makeHttpRequest(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(15000);
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");

        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();

        return response.toString();
    }
}
