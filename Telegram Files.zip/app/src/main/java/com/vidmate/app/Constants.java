package com.vidmate.app;

public class Constants {

    // YouTube Data API v3 - Replace with your API key
    public static final String YOUTUBE_API_KEY = "AIzaSyYOUR_API_KEY_HERE";
    public static final String YOUTUBE_BASE_URL = "https://www.googleapis.com/youtube/v3/";

    // Alternative: RapidAPI for more features (optional)
    public static final String RAPID_API_KEY = "YOUR_RAPID_API_KEY";

    // Download Settings
    public static final String DOWNLOAD_PATH = "/VidMate/Downloads";
    public static final int MAX_CONCURRENT_DOWNLOADS = 3;

    // Video Quality Options
    public static final String[] QUALITIES = {
        "144p", "240p", "360p", "480p", "720p", "1080p", "1440p", "2160p", "Audio Only"
    };

    // Format Options
    public static final String[] FORMATS = {
        "MP4", "WEBM", "MKV", "MP3", "M4A"
    };

    // Tab Constants
    public static final int TAB_HOME = 0;
    public static final int TAB_TRENDING = 1;
    public static final int TAB_DOWNLOADS = 2;
    public static final int TAB_LIBRARY = 3;

    // Intent Extras
    public static final String EXTRA_VIDEO_ID = "video_id";
    public static final String EXTRA_VIDEO_TITLE = "video_title";
    public static final String EXTRA_VIDEO_THUMB = "video_thumb";
    public static final String EXTRA_CHANNEL_NAME = "channel_name";
}
