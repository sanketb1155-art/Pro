package com.vidmate.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.vidmate.app.adapter.VideoAdapter;
import com.vidmate.app.model.VideoItem;
import com.vidmate.app.utils.PreferenceManager;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    private RecyclerView historyRecycler;
    private TextView emptyText;
    private VideoAdapter videoAdapter;
    private PreferenceManager prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("History");

        prefs = new PreferenceManager(this);

        initViews();
        setupRecyclerView();
        loadHistory();
    }

    private void initViews() {
        historyRecycler = findViewById(R.id.historyRecycler);
        emptyText = findViewById(R.id.emptyText);
    }

    private void setupRecyclerView() {
        videoAdapter = new VideoAdapter(this);
        historyRecycler.setLayoutManager(new LinearLayoutManager(this));
        historyRecycler.setAdapter(videoAdapter);

        videoAdapter.setOnVideoClickListener(new VideoAdapter.OnVideoClickListener() {
            public void onVideoClick(VideoItem video, int position) {
                Intent intent = new Intent(HistoryActivity.this, PlayerActivity.class);
                intent.putExtra(Constants.EXTRA_VIDEO_ID, video.getVideoId());
                intent.putExtra(Constants.EXTRA_VIDEO_TITLE, video.getTitle());
                intent.putExtra(Constants.EXTRA_VIDEO_THUMB, video.getBestThumbnail());
                intent.putExtra(Constants.EXTRA_CHANNEL_NAME, video.getChannelTitle());
                startActivity(intent);
            }
        });
    }

    private void loadHistory() {
        List<VideoItem> history = prefs.getHistory();
        videoAdapter.setVideos(history);

        if (history.size() == 0) {
            emptyText.setVisibility(View.VISIBLE);
            emptyText.setText("No watch history");
        } else {
            emptyText.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHistory();
    }
}
