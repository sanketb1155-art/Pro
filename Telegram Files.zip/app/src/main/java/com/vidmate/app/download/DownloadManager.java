package com.vidmate.app.download;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import androidx.core.app.NotificationCompat;
import com.vidmate.app.Constants;
import com.vidmate.app.PlayerActivity;
import com.vidmate.app.R;
import com.vidmate.app.model.DownloadItem;
import com.vidmate.app.utils.PreferenceManager;
import com.vidmate.app.utils.Utils;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DownloadManager {

    private Context context;
    private PreferenceManager prefs;
    private ExecutorService executorService;
    private List<DownloadListener> listeners;
    private List<DownloadTask> activeTasks;
    private NotificationManager notificationManager;
    private static final String CHANNEL_ID = "vidmate_downloads";
    private static final int NOTIFICATION_ID = 1001;

    public interface DownloadListener {
        void onProgressUpdate(DownloadItem item);
        void onDownloadComplete(DownloadItem item);
        void onDownloadFailed(DownloadItem item, String error);
    }

    public DownloadManager(Context context) {
        this.context = context;
        this.prefs = new PreferenceManager(context);
        this.listeners = new ArrayList<DownloadListener>();
        this.activeTasks = new ArrayList<DownloadTask>();
        this.executorService = Executors.newFixedThreadPool(prefs.getConcurrentDownloads());
        this.notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createNotificationChannel();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "VidMate Downloads",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Shows download progress");
            notificationManager.createNotificationChannel(channel);
        }
    }

    public void addListener(DownloadListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public void removeListener(DownloadListener listener) {
        listeners.remove(listener);
    }

    public void startDownload(DownloadItem item) {
        File downloadDir = new File(Environment.getExternalStorageDirectory(), Constants.DOWNLOAD_PATH);
        if (!downloadDir.exists()) {
            downloadDir.mkdirs();
        }

        String fileName = sanitizeFileName(item.getTitle()) + "_" + item.getQuality() + "." + item.getFormat().toLowerCase();
        File outputFile = new File(downloadDir, fileName);
        item.setFilePath(outputFile.getAbsolutePath());
        item.setStatus(DownloadItem.STATUS_DOWNLOADING);

        DownloadTask task = new DownloadTask(item);
        activeTasks.add(task);
        executorService.execute(task);

        showNotification(item);
    }

    public void pauseDownload(DownloadItem item) {
        for (int i = 0; i < activeTasks.size(); i++) {
            DownloadTask task = activeTasks.get(i);
            if (task.getItem().getId().equals(item.getId())) {
                task.pause();
                break;
            }
        }
    }

    public void resumeDownload(DownloadItem item) {
        item.setStatus(DownloadItem.STATUS_DOWNLOADING);
        DownloadTask task = new DownloadTask(item);
        activeTasks.add(task);
        executorService.execute(task);
    }

    public void cancelDownload(DownloadItem item) {
        for (int i = 0; i < activeTasks.size(); i++) {
            DownloadTask task = activeTasks.get(i);
            if (task.getItem().getId().equals(item.getId())) {
                task.cancel();
                activeTasks.remove(i);
                break;
            }
        }
    }

    public void deleteDownload(DownloadItem item) {
        cancelDownload(item);
        if (item.getFilePath() != null) {
            File file = new File(item.getFilePath());
            if (file.exists()) {
                file.delete();
            }
        }
    }

    private String sanitizeFileName(String name) {
        return name.replaceAll("[^a-zA-Z0-9\u0900-\u097F\s-]", "").replaceAll("\s+", "_").trim();
    }

    private void showNotification(DownloadItem item) {
        Intent intent = new Intent(context, PlayerActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Downloading: " + item.getTitle())
            .setContentText(item.getProgress() + "% - " + Utils.formatFileSize(item.getDownloadedSize()) + "/" + Utils.formatFileSize(item.getTotalSize()))
            .setProgress(100, item.getProgress(), false)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true);

        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }

    private void updateNotification(DownloadItem item) {
        showNotification(item);
    }

    private void showCompleteNotification(DownloadItem item) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Download Complete")
            .setContentText(item.getTitle())
            .setAutoCancel(true);

        notificationManager.notify(NOTIFICATION_ID + 1, builder.build());
    }

    private class DownloadTask implements Runnable {
        private DownloadItem item;
        private volatile boolean paused = false;
        private volatile boolean cancelled = false;
        private Handler mainHandler = new Handler(Looper.getMainLooper());

        public DownloadTask(DownloadItem item) {
            this.item = item;
        }

        public DownloadItem getItem() {
            return item;
        }

        public void pause() {
            paused = true;
        }

        public void cancel() {
            cancelled = true;
        }

        @Override
        public void run() {
            HttpURLConnection connection = null;
            FileOutputStream outputStream = null;
            InputStream inputStream = null;

            try {
                URL url = new URL(item.getDownloadUrl());
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(30000);
                connection.setReadTimeout(30000);
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");

                if (item.getDownloadedSize() > 0) {
                    connection.setRequestProperty("Range", "bytes=" + item.getDownloadedSize() + "-");
                }

                int responseCode = connection.getResponseCode();
                if (responseCode != HttpURLConnection.HTTP_OK && responseCode != HttpURLConnection.HTTP_PARTIAL) {
                    throw new Exception("Server returned " + responseCode);
                }

                long totalSize = connection.getContentLength() + item.getDownloadedSize();
                item.setTotalSize(totalSize);

                inputStream = connection.getInputStream();
                outputStream = new FileOutputStream(item.getFilePath(), item.getDownloadedSize() > 0);

                byte[] buffer = new byte[8192];
                int bytesRead;
                long lastUpdateTime = 0;

                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    if (cancelled) {
                        throw new Exception("Download cancelled");
                    }

                    if (paused) {
                        item.setStatus(DownloadItem.STATUS_PAUSED);
                        mainHandler.post(new Runnable() {
                            public void run() {
                                for (int i = 0; i < listeners.size(); i++) {
                                    listeners.get(i).onProgressUpdate(item);
                                }
                            }
                        });
                        return;
                    }

                    outputStream.write(buffer, 0, bytesRead);
                    item.setDownloadedSize(item.getDownloadedSize() + bytesRead);

                    long currentTime = System.currentTimeMillis();
                    if (currentTime - lastUpdateTime > 500) {
                        lastUpdateTime = currentTime;
                        mainHandler.post(new Runnable() {
                            public void run() {
                                for (int i = 0; i < listeners.size(); i++) {
                                    listeners.get(i).onProgressUpdate(item);
                                }
                                updateNotification(item);
                            }
                        });
                    }
                }

                outputStream.flush();
                item.setStatus(DownloadItem.STATUS_COMPLETED);

                mainHandler.post(new Runnable() {
                    public void run() {
                        for (int i = 0; i < listeners.size(); i++) {
                            listeners.get(i).onDownloadComplete(item);
                        }
                        showCompleteNotification(item);
                    }
                });

            } catch (Exception e) {
                item.setStatus(DownloadItem.STATUS_FAILED);
                final String error = e.getMessage();
                mainHandler.post(new Runnable() {
                    public void run() {
                        for (int i = 0; i < listeners.size(); i++) {
                            listeners.get(i).onDownloadFailed(item, error);
                        }
                    }
                });
            } finally {
                try {
                    if (outputStream != null) outputStream.close();
                    if (inputStream != null) inputStream.close();
                    if (connection != null) connection.disconnect();
                } catch (Exception e) {}
                activeTasks.remove(this);
            }
        }
    }
}
