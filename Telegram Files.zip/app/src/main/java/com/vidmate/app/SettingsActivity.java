package com.vidmate.app;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.vidmate.app.utils.PreferenceManager;

public class SettingsActivity extends AppCompatActivity {

    private Switch darkModeSwitch;
    private Switch wifiOnlySwitch;
    private Spinner qualitySpinner;
    private Spinner formatSpinner;
    private SeekBar concurrentSeekBar;
    private TextView concurrentValue;
    private PreferenceManager prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Settings");

        prefs = new PreferenceManager(this);

        initViews();
        loadSettings();
    }

    private void initViews() {
        darkModeSwitch = findViewById(R.id.darkModeSwitch);
        wifiOnlySwitch = findViewById(R.id.wifiOnlySwitch);
        qualitySpinner = findViewById(R.id.qualitySpinner);
        formatSpinner = findViewById(R.id.formatSpinner);
        concurrentSeekBar = findViewById(R.id.concurrentSeekBar);
        concurrentValue = findViewById(R.id.concurrentValue);

        darkModeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                prefs.setDarkMode(isChecked);
                Toast.makeText(SettingsActivity.this, "Restart app to apply theme", Toast.LENGTH_SHORT).show();
            }
        });

        wifiOnlySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                prefs.setWifiOnly(isChecked);
            }
        });

        concurrentSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int value = progress + 1;
                concurrentValue.setText(String.valueOf(value));
                prefs.setConcurrentDownloads(value);
            }
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void loadSettings() {
        darkModeSwitch.setChecked(prefs.isDarkMode());
        wifiOnlySwitch.setChecked(prefs.isWifiOnly());
        concurrentSeekBar.setProgress(prefs.getConcurrentDownloads() - 1);
        concurrentValue.setText(String.valueOf(prefs.getConcurrentDownloads()));

        // Set default quality
        String defaultQuality = prefs.getDefaultQuality();
        for (int i = 0; i < Constants.QUALITIES.length; i++) {
            if (Constants.QUALITIES[i].equals(defaultQuality)) {
                qualitySpinner.setSelection(i);
                break;
            }
        }

        // Set default format
        String defaultFormat = prefs.getDefaultFormat();
        for (int i = 0; i < Constants.FORMATS.length; i++) {
            if (Constants.FORMATS[i].equals(defaultFormat)) {
                formatSpinner.setSelection(i);
                break;
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
