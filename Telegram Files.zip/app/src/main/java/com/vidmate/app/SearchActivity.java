package com.vidmate.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.vidmate.app.adapter.VideoAdapter;
import com.vidmate.app.model.SearchResponse;
import com.vidmate.app.model.VideoItem;
import com.vidmate.app.network.RetrofitClient;
import com.vidmate.app.network.YouTubeApiService;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchActivity extends AppCompatActivity {

    private EditText searchEdit;
    private ImageButton backButton;
    private ImageButton clearButton;
    private RecyclerView resultsRecycler;
    private ProgressBar progressBar;
    private TextView emptyText;

    private VideoAdapter videoAdapter;
    private YouTubeApiService apiService;
    private String nextPageToken = null;
    private boolean isLoading = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        apiService = RetrofitClient.getApiService();

        initViews();
        setupRecyclerView();
        setupSearch();
    }

    private void initViews() {
        searchEdit = findViewById(R.id.searchEdit);
        backButton = findViewById(R.id.backButton);
        clearButton = findViewById(R.id.clearButton);
        resultsRecycler = findViewById(R.id.resultsRecycler);
        progressBar = findViewById(R.id.progressBar);
        emptyText = findViewById(R.id.emptyText);

        backButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });

        clearButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                searchEdit.setText("");
                videoAdapter.clear();
                emptyText.setVisibility(View.VISIBLE);
                emptyText.setText("Type to search videos");
            }
        });

        clearButton.setVisibility(View.GONE);
    }

    private void setupRecyclerView() {
        videoAdapter = new VideoAdapter(this);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        resultsRecycler.setLayoutManager(layoutManager);
        resultsRecycler.setAdapter(videoAdapter);

        videoAdapter.setOnVideoClickListener(new VideoAdapter.OnVideoClickListener() {
            public void onVideoClick(VideoItem video, int position) {
                Intent intent = new Intent(SearchActivity.this, PlayerActivity.class);
                intent.putExtra(Constants.EXTRA_VIDEO_ID, video.getVideoId());
                intent.putExtra(Constants.EXTRA_VIDEO_TITLE, video.getTitle());
                intent.putExtra(Constants.EXTRA_VIDEO_THUMB, video.getBestThumbnail());
                intent.putExtra(Constants.EXTRA_CHANNEL_NAME, video.getChannelTitle());
                startActivity(intent);
            }
        });

        // Infinite scroll
        resultsRecycler.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager lm = (LinearLayoutManager) recyclerView.getLayoutManager();
                int visibleItemCount = lm.getChildCount();
                int totalItemCount = lm.getItemCount();
                int firstVisibleItem = lm.findFirstVisibleItemPosition();

                if (!isLoading && nextPageToken != null) {
                    if ((visibleItemCount + firstVisibleItem) >= totalItemCount - 5) {
                        loadMoreResults();
                    }
                }
            }
        });
    }

    private void setupSearch() {
        searchEdit.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    performSearch(v.getText().toString().trim());
                    return true;
                }
                return false;
            }
        });

        searchEdit.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                clearButton.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
            }
            public void afterTextChanged(Editable s) {}
        });
    }

    private void performSearch(String query) {
        if (query.isEmpty()) return;

        progressBar.setVisibility(View.VISIBLE);
        emptyText.setVisibility(View.GONE);
        nextPageToken = null;

        Call<SearchResponse> call = apiService.searchVideosSimple(
            "snippet", query, "video", 25, Constants.YOUTUBE_API_KEY
        );

        call.enqueue(new Callback<SearchResponse>() {
            public void onResponse(Call<SearchResponse> call, Response<SearchResponse> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null) {
                    List<VideoItem> videos = parseResults(response.body());
                    videoAdapter.setVideos(videos);
                    nextPageToken = response.body().getNextPageToken();

                    if (videos.size() == 0) {
                        emptyText.setVisibility(View.VISIBLE);
                        emptyText.setText("No results found");
                    }
                }
            }

            public void onFailure(Call<SearchResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(SearchActivity.this, "Search failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadMoreResults() {
        if (isLoading || nextPageToken == null) return;
        isLoading = true;

        String query = searchEdit.getText().toString().trim();

        Call<SearchResponse> call = apiService.searchVideos(
            "snippet", query, "video", 25, Constants.YOUTUBE_API_KEY, nextPageToken
        );

        call.enqueue(new Callback<SearchResponse>() {
            public void onResponse(Call<SearchResponse> call, Response<SearchResponse> response) {
                isLoading = false;
                if (response.isSuccessful() && response.body() != null) {
                    List<VideoItem> videos = parseResults(response.body());
                    videoAdapter.addVideos(videos);
                    nextPageToken = response.body().getNextPageToken();
                }
            }

            public void onFailure(Call<SearchResponse> call, Throwable t) {
                isLoading = false;
            }
        });
    }

    private List<VideoItem> parseResults(SearchResponse response) {
        List<VideoItem> videos = new ArrayList<VideoItem>();

        if (response.getItems() == null) return videos;

        for (int i = 0; i < response.getItems().size(); i++) {
            SearchResponse.SearchItem item = response.getItems().get(i);
            if (item.getId() == null || item.getId().getVideoId() == null) continue;

            VideoItem video = new VideoItem();
            video.setVideoId(item.getId().getVideoId());

            if (item.getSnippet() != null) {
                video.setTitle(item.getSnippet().getTitle());
                video.setDescription(item.getSnippet().getDescription());
                video.setChannelTitle(item.getSnippet().getChannelTitle());
                video.setPublishedAt(item.getSnippet().getPublishedAt());

                if (item.getSnippet().getThumbnails() != null) {
                    SearchResponse.Thumbnails thumbs = item.getSnippet().getThumbnails();
                    if (thumbs.getHigh() != null) {
                        video.setThumbnailUrl(thumbs.getHigh().getUrl());
                    } else if (thumbs.getMedium() != null) {
                        video.setThumbnailUrl(thumbs.getMedium().getUrl());
                    }
                }
            }

            videos.add(video);
        }

        return videos;
    }
}
