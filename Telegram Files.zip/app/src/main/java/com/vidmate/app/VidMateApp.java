package com.vidmate.app;

import android.app.Application;
import androidx.multidex.MultiDexApplication;
import com.vidmate.app.download.DownloadManager;
import com.vidmate.app.utils.PreferenceManager;

public class VidMateApp extends MultiDexApplication {

    private static VidMateApp instance;
    private DownloadManager downloadManager;
    private PreferenceManager preferenceManager;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        preferenceManager = new PreferenceManager(this);
        downloadManager = new DownloadManager(this);
    }

    public static VidMateApp getInstance() {
        return instance;
    }

    public DownloadManager getDownloadManager() {
        return downloadManager;
    }

    public PreferenceManager getPrefs() {
        return preferenceManager;
    }
}
