package com.vidmate.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.vidmate.app.adapter.VideoAdapter;
import com.vidmate.app.model.SearchResponse;
import com.vidmate.app.model.VideoItem;
import com.vidmate.app.network.RetrofitClient;
import com.vidmate.app.network.YouTubeApiService;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TrendingActivity extends AppCompatActivity {

    private RecyclerView trendingRecycler;
    private ProgressBar progressBar;
    private VideoAdapter videoAdapter;
    private YouTubeApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trending);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Trending");

        apiService = RetrofitClient.getApiService();

        initViews();
        setupRecyclerView();
        loadTrending();
    }

    private void initViews() {
        trendingRecycler = findViewById(R.id.trendingRecycler);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setupRecyclerView() {
        videoAdapter = new VideoAdapter(this);
        trendingRecycler.setLayoutManager(new LinearLayoutManager(this));
        trendingRecycler.setAdapter(videoAdapter);

        videoAdapter.setOnVideoClickListener(new VideoAdapter.OnVideoClickListener() {
            public void onVideoClick(VideoItem video, int position) {
                Intent intent = new Intent(TrendingActivity.this, PlayerActivity.class);
                intent.putExtra(Constants.EXTRA_VIDEO_ID, video.getVideoId());
                intent.putExtra(Constants.EXTRA_VIDEO_TITLE, video.getTitle());
                intent.putExtra(Constants.EXTRA_VIDEO_THUMB, video.getBestThumbnail());
                intent.putExtra(Constants.EXTRA_CHANNEL_NAME, video.getChannelTitle());
                startActivity(intent);
            }
        });
    }

    private void loadTrending() {
        progressBar.setVisibility(View.VISIBLE);

        Call<SearchResponse> call = apiService.getTrendingVideos(
            "snippet", "", "video", "viewCount", 50, Constants.YOUTUBE_API_KEY
        );

        call.enqueue(new Callback<SearchResponse>() {
            public void onResponse(Call<SearchResponse> call, Response<SearchResponse> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null) {
                    List<VideoItem> videos = parseResults(response.body());
                    videoAdapter.setVideos(videos);
                }
            }

            public void onFailure(Call<SearchResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(TrendingActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private List<VideoItem> parseResults(SearchResponse response) {
        List<VideoItem> videos = new ArrayList<VideoItem>();

        if (response.getItems() == null) return videos;

        for (int i = 0; i < response.getItems().size(); i++) {
            SearchResponse.SearchItem item = response.getItems().get(i);
            if (item.getId() == null || item.getId().getVideoId() == null) continue;

            VideoItem video = new VideoItem();
            video.setVideoId(item.getId().getVideoId());

            if (item.getSnippet() != null) {
                video.setTitle(item.getSnippet().getTitle());
                video.setDescription(item.getSnippet().getDescription());
                video.setChannelTitle(item.getSnippet().getChannelTitle());
                video.setPublishedAt(item.getSnippet().getPublishedAt());

                if (item.getSnippet().getThumbnails() != null) {
                    SearchResponse.Thumbnails thumbs = item.getSnippet().getThumbnails();
                    if (thumbs.getHigh() != null) {
                        video.setThumbnailUrl(thumbs.getHigh().getUrl());
                    } else if (thumbs.getMedium() != null) {
                        video.setThumbnailUrl(thumbs.getMedium().getUrl());
                    }
                }
            }

            videos.add(video);
        }

        return videos;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
