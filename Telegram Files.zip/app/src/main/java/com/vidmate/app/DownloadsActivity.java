package com.vidmate.app;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.vidmate.app.adapter.DownloadAdapter;
import com.vidmate.app.download.DownloadManager;
import com.vidmate.app.model.DownloadItem;
import com.vidmate.app.utils.PreferenceManager;
import java.io.File;
import java.util.List;

public class DownloadsActivity extends AppCompatActivity implements DownloadManager.DownloadListener {

    private RecyclerView downloadRecycler;
    private TextView emptyText;
    private DownloadAdapter downloadAdapter;
    private PreferenceManager prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_downloads);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Downloads");

        prefs = new PreferenceManager(this);

        initViews();
        setupRecyclerView();
        loadDownloads();

        VidMateApp.getInstance().getDownloadManager().addListener(this);
    }

    private void initViews() {
        downloadRecycler = findViewById(R.id.downloadRecycler);
        emptyText = findViewById(R.id.emptyText);
    }

    private void setupRecyclerView() {
        downloadAdapter = new DownloadAdapter(this);
        downloadRecycler.setLayoutManager(new LinearLayoutManager(this));
        downloadRecycler.setAdapter(downloadAdapter);

        downloadAdapter.setOnDownloadActionListener(new DownloadAdapter.OnDownloadActionListener() {
            public void onPause(DownloadItem item) {
                VidMateApp.getInstance().getDownloadManager().pauseDownload(item);
            }

            public void onResume(DownloadItem item) {
                VidMateApp.getInstance().getDownloadManager().resumeDownload(item);
            }

            public void onCancel(DownloadItem item) {
                VidMateApp.getInstance().getDownloadManager().cancelDownload(item);
            }

            public void onDelete(final DownloadItem item) {
                new AlertDialog.Builder(DownloadsActivity.this)
                    .setTitle("Delete Download")
                    .setMessage("Delete "" + item.getTitle() + ""?")
                    .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            VidMateApp.getInstance().getDownloadManager().deleteDownload(item);
                            loadDownloads();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            }

            public void onOpen(DownloadItem item) {
                openDownloadedFile(item);
            }
        });
    }

    private void loadDownloads() {
        List<DownloadItem> downloads = prefs.getDownloads();
        downloadAdapter.setDownloads(downloads);

        if (downloads.size() == 0) {
            emptyText.setVisibility(View.VISIBLE);
            emptyText.setText("No downloads yet");
        } else {
            emptyText.setVisibility(View.GONE);
        }
    }

    private void openDownloadedFile(DownloadItem item) {
        File file = new File(item.getFilePath());
        if (!file.exists()) {
            Toast.makeText(this, "File not found", Toast.LENGTH_SHORT).show();
            return;
        }

        Uri uri = androidx.core.content.FileProvider.getUriForFile(
            this, getPackageName() + ".provider", file
        );

        Intent intent = new Intent(Intent.ACTION_VIEW);
        String mimeType = item.getFormat().equalsIgnoreCase("MP3") || item.getFormat().equalsIgnoreCase("M4A") 
            ? "audio/*" : "video/*";
        intent.setDataAndType(uri, mimeType);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No app found to open this file", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onProgressUpdate(DownloadItem item) {
        downloadAdapter.updateItem(item);
    }

    @Override
    public void onDownloadComplete(DownloadItem item) {
        downloadAdapter.updateItem(item);
        saveDownloads();
        Toast.makeText(this, "Download complete: " + item.getTitle(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDownloadFailed(DownloadItem item, String error) {
        downloadAdapter.updateItem(item);
        saveDownloads();
    }

    private void saveDownloads() {
        prefs.saveDownloads(downloadAdapter.getDownloads());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        VidMateApp.getInstance().getDownloadManager().removeListener(this);
    }
}
