import { Router, type IRouter } from "express";
import { eq, and, desc } from "drizzle-orm";
import { db, commandsTable } from "@workspace/db";
import {
  CreateCommandBody,
  CompleteCommandParams,
  GetPendingCommandsQueryParams,
  ListCommandsQueryParams,
  ListCommandsResponse,
  GetPendingCommandsResponse,
  CompleteCommandResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/commands/pending", async (req, res): Promise<void> => {
  const parsed = GetPendingCommandsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const commands = await db
    .select()
    .from(commandsTable)
    .where(
      and(
        eq(commandsTable.deviceId, parsed.data.deviceId),
        eq(commandsTable.status, "pending")
      )
    )
    .orderBy(commandsTable.createdAt);

  res.json(GetPendingCommandsResponse.parse(commands.map(formatCommand)));
});

router.get("/commands", async (req, res): Promise<void> => {
  const parsed = ListCommandsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { deviceId } = parsed.data;

  const commands = await db
    .select()
    .from(commandsTable)
    .where(deviceId ? eq(commandsTable.deviceId, deviceId) : undefined)
    .orderBy(desc(commandsTable.createdAt))
    .limit(100);

  res.json(ListCommandsResponse.parse(commands.map(formatCommand)));
});

router.post("/commands", async (req, res): Promise<void> => {
  const parsed = CreateCommandBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { deviceId, type } = parsed.data;

  const [command] = await db
    .insert(commandsTable)
    .values({ deviceId, type, status: "pending" })
    .returning();

  res.status(201).json(formatCommand(command));
});

router.put("/commands/:id/complete", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = CompleteCommandParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [command] = await db
    .update(commandsTable)
    .set({ status: "completed", completedAt: new Date() })
    .where(eq(commandsTable.id, params.data.id))
    .returning();

  if (!command) {
    res.status(404).json({ error: "Command not found" });
    return;
  }

  res.json(CompleteCommandResponse.parse(formatCommand(command)));
});

function formatCommand(command: typeof commandsTable.$inferSelect) {
  return {
    ...command,
    createdAt: command.createdAt.toISOString(),
    completedAt: command.completedAt?.toISOString() ?? null,
  };
}

export default router;
