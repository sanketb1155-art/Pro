import { Router, type IRouter } from "express";
import { eq, desc, and } from "drizzle-orm";
import { db, eventsTable, devicesTable } from "@workspace/db";
import {
  CreateEventBody,
  ListEventsQueryParams,
  ListEventsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/events", async (req, res): Promise<void> => {
  const parsed = ListEventsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { deviceId, type, limit } = parsed.data;
  const conditions = [];

  if (deviceId) conditions.push(eq(eventsTable.deviceId, deviceId));
  if (type) conditions.push(eq(eventsTable.type, type));

  const events = await db
    .select()
    .from(eventsTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(eventsTable.createdAt))
    .limit(limit ?? 50);

  res.json(ListEventsResponse.parse(events.map(formatEvent)));
});

router.post("/events", async (req, res): Promise<void> => {
  const parsed = CreateEventBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { deviceId, type, latitude, longitude, photoUrl, notes } = parsed.data;

  const [event] = await db
    .insert(eventsTable)
    .values({
      deviceId,
      type,
      latitude: latitude ?? null,
      longitude: longitude ?? null,
      photoUrl: photoUrl ?? null,
      notes: notes ?? null,
    })
    .returning();

  const existing = await db
    .select({ id: devicesTable.id })
    .from(devicesTable)
    .where(eq(devicesTable.deviceId, deviceId));

  if (existing.length === 0) {
    await db.insert(devicesTable).values({
      deviceId,
      name: "Unknown Device",
      model: "Android",
      androidVersion: "Unknown",
      status: "active",
      protectionEnabled: true,
      lastSeen: new Date(),
      latitude: type === "location" ? (latitude ?? null) : null,
      longitude: type === "location" ? (longitude ?? null) : null,
    });
    req.log.info({ deviceId }, "Auto-registered unknown device from event");
  } else if (type === "location" && latitude != null && longitude != null) {
    await db
      .update(devicesTable)
      .set({ latitude, longitude, lastSeen: new Date() })
      .where(eq(devicesTable.deviceId, deviceId));
  } else {
    await db
      .update(devicesTable)
      .set({ lastSeen: new Date() })
      .where(eq(devicesTable.deviceId, deviceId));
  }

  res.status(201).json(formatEvent(event));
});

function formatEvent(event: typeof eventsTable.$inferSelect) {
  return {
    ...event,
    createdAt: event.createdAt.toISOString(),
  };
}

export default router;
