import { Router, type IRouter } from "express";
import { eq, desc, sql } from "drizzle-orm";
import { db, devicesTable, eventsTable, commandsTable } from "@workspace/db";
import {
  RegisterDeviceBody,
  RegisterDeviceResponse,
  DeviceHeartbeatBody,
  DeviceHeartbeatResponse,
  GetDeviceParams,
  GetDeviceResponse,
  ListDevicesResponseItem,
  ListDevicesResponse,
  GetDashboardStatsResponse,
} from "@workspace/api-zod";
import { logger } from "../lib/logger";

const router: IRouter = Router();

router.get("/devices", async (_req, res): Promise<void> => {
  const devices = await db
    .select()
    .from(devicesTable)
    .orderBy(desc(devicesTable.lastSeen));
  res.json(ListDevicesResponse.parse(devices.map(formatDevice)));
});

router.post("/devices", async (req, res): Promise<void> => {
  const parsed = RegisterDeviceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { deviceId, name, model, androidVersion, batteryLevel, status, protectionEnabled } = parsed.data;

  const existing = await db.select().from(devicesTable).where(eq(devicesTable.deviceId, deviceId));

  let device;
  if (existing.length > 0) {
    const [updated] = await db
      .update(devicesTable)
      .set({
        name,
        model,
        androidVersion,
        batteryLevel: batteryLevel ?? null,
        status: status ?? "active",
        protectionEnabled: protectionEnabled ?? true,
        lastSeen: new Date(),
      })
      .where(eq(devicesTable.deviceId, deviceId))
      .returning();
    device = updated;
  } else {
    const [created] = await db
      .insert(devicesTable)
      .values({
        deviceId,
        name,
        model,
        androidVersion,
        batteryLevel: batteryLevel ?? null,
        status: status ?? "active",
        protectionEnabled: protectionEnabled ?? true,
        lastSeen: new Date(),
      })
      .returning();
    device = created;
  }

  req.log.info({ deviceId }, "Device registered/updated");
  res.json(RegisterDeviceResponse.parse(formatDevice(device)));
});

router.post("/devices/heartbeat", async (req, res): Promise<void> => {
  const parsed = DeviceHeartbeatBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { deviceId, batteryLevel, status } = parsed.data;

  const [updated] = await db
    .update(devicesTable)
    .set({
      batteryLevel: batteryLevel ?? null,
      status: status ?? "active",
      lastSeen: new Date(),
    })
    .where(eq(devicesTable.deviceId, deviceId))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Device not found" });
    return;
  }

  res.json(DeviceHeartbeatResponse.parse(formatDevice(updated)));
});

router.get("/devices/:deviceId", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.deviceId) ? req.params.deviceId[0] : req.params.deviceId;
  const params = GetDeviceParams.safeParse({ deviceId: raw });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [device] = await db
    .select()
    .from(devicesTable)
    .where(eq(devicesTable.deviceId, params.data.deviceId));

  if (!device) {
    res.status(404).json({ error: "Device not found" });
    return;
  }

  res.json(GetDeviceResponse.parse(formatDevice(device)));
});

router.get("/stats", async (_req, res): Promise<void> => {
  const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
  const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

  const [totalDevicesRow] = await db.select({ count: sql<number>`count(*)::int` }).from(devicesTable);
  const [activeDevicesRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(devicesTable)
    .where(sql`${devicesTable.lastSeen} >= ${fiveMinutesAgo}`);
  const [totalEventsRow] = await db.select({ count: sql<number>`count(*)::int` }).from(eventsTable);
  const [recentEventsRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(eventsTable)
    .where(sql`${eventsTable.createdAt} >= ${oneDayAgo}`);
  const [pendingCommandsRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(commandsTable)
    .where(eq(commandsTable.status, "pending"));

  const stats = {
    totalDevices: totalDevicesRow?.count ?? 0,
    activeDevices: activeDevicesRow?.count ?? 0,
    totalEvents: totalEventsRow?.count ?? 0,
    recentEvents: recentEventsRow?.count ?? 0,
    pendingCommands: pendingCommandsRow?.count ?? 0,
  };

  res.json(GetDashboardStatsResponse.parse(stats));
});

function formatDevice(device: typeof devicesTable.$inferSelect) {
  return {
    ...device,
    lastSeen: device.lastSeen?.toISOString() ?? null,
    createdAt: device.createdAt.toISOString(),
  };
}

export default router;
