import { Router, type IRouter } from "express";
import healthRouter from "./health";
import devicesRouter from "./devices";
import eventsRouter from "./events";
import commandsRouter from "./commands";

const router: IRouter = Router();

router.use(healthRouter);
router.use(devicesRouter);
router.use(eventsRouter);
router.use(commandsRouter);

export default router;
