import { MapPin, Camera, Unlock, Power, AlertCircle } from "lucide-react";

interface EventBadgeProps {
  type: string;
}

export function EventBadge({ type }: EventBadgeProps) {
  const getBadgeConfig = () => {
    switch (type.toLowerCase()) {
      case "location":
        return {
          icon: MapPin,
          colorClass: "text-blue-500 bg-blue-500/10 border-blue-500/20",
          label: "LOC"
        };
      case "photo":
        return {
          icon: Camera,
          colorClass: "text-purple-500 bg-purple-500/10 border-purple-500/20",
          label: "IMG"
        };
      case "unlock":
        return {
          icon: Unlock,
          colorClass: "text-yellow-500 bg-yellow-500/10 border-yellow-500/20",
          label: "ULK"
        };
      case "boot":
        return {
          icon: Power,
          colorClass: "text-green-500 bg-green-500/10 border-green-500/20",
          label: "PWR"
        };
      case "alert":
        return {
          icon: AlertCircle,
          colorClass: "text-red-500 bg-red-500/10 border-red-500/20",
          label: "ALT"
        };
      default:
        return {
          icon: AlertCircle,
          colorClass: "text-muted-foreground bg-muted/10 border-border",
          label: "UNK"
        };
    }
  };

  const config = getBadgeConfig();
  const Icon = config.icon;

  return (
    <div className={`flex items-center justify-center p-1.5 rounded-sm border ${config.colorClass}`} title={type.toUpperCase()}>
      <Icon className="w-4 h-4" />
    </div>
  );
}
