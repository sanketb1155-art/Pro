import { Link, useLocation } from "wouter";
import { Activity, Shield, Smartphone, RadioTower, TerminalSquare } from "lucide-react";
import { useHealthCheck, getHealthCheckQueryKey } from "@workspace/api-client-react";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { data: health, isError } = useHealthCheck({
    query: { refetchInterval: 30000, queryKey: getHealthCheckQueryKey() }
  });

  const navItems = [
    { href: "/", label: "Dashboard", icon: Activity },
    { href: "/devices", label: "Devices", icon: Smartphone },
    { href: "/events", label: "Event Feed", icon: RadioTower },
    { href: "/simulator", label: "Simulator", icon: TerminalSquare },
  ];

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden dark">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border bg-card flex flex-col z-20 shadow-[4px_0_24px_rgba(0,0,0,0.5)]">
        <div className="p-6 flex items-center gap-3 border-b border-border/50">
          <Shield className="w-8 h-8 text-primary shadow-[0_0_15px_var(--color-primary)] rounded-full bg-primary/10 p-1.5" />
          <div>
            <h1 className="font-mono font-bold text-sm tracking-widest text-primary uppercase drop-shadow-[0_0_8px_var(--color-primary)]">TITAN</h1>
            <p className="text-[10px] text-muted-foreground tracking-widest uppercase">Admin Terminal</p>
          </div>
        </div>
        <nav className="flex-1 px-4 py-6 space-y-2">
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            return (
              <Link 
                key={item.href} 
                href={item.href}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-sm text-sm font-mono transition-all duration-300 relative group ${
                  isActive 
                    ? "text-primary bg-primary/10 border border-primary/30" 
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary border border-transparent"
                }`}
              >
                {isActive && (
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary shadow-[0_0_10px_var(--color-primary)]" />
                )}
                <item.icon className={`w-4 h-4 transition-colors ${isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"}`} />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-4 border-t border-border/50 bg-background/50">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-muted-foreground uppercase">API Link</span>
            <div className={`flex items-center gap-2 ${isError ? 'text-destructive' : 'text-primary'}`}>
              <div className={`w-2 h-2 rounded-full ${isError ? 'bg-destructive shadow-[0_0_8px_var(--color-destructive)]' : 'bg-primary shadow-[0_0_8px_var(--color-primary)] animate-pulse'}`} />
              {isError ? 'OFFLINE' : (health?.status || 'ONLINE').toUpperCase()}
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* Subtle grid background for tactical feel */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none z-0" />
        
        <header className="h-14 border-b border-border bg-background/90 backdrop-blur-md flex items-center px-8 shrink-0 z-10">
          <div className="flex-1 flex items-center gap-4">
            <h2 className="text-xs font-mono text-muted-foreground tracking-widest uppercase">
              {location === "/" ? "Global Overview" : location.replace("/", "").replace("/", " / ")}
            </h2>
          </div>
          <div className="text-xs font-mono text-primary flex items-center gap-2 bg-primary/10 px-3 py-1.5 rounded border border-primary/20 shadow-[inset_0_0_10px_rgba(var(--color-primary),0.1)]">
            <Activity className="w-3 h-3" />
            LIVE FEED
          </div>
        </header>
        
        <div className="flex-1 overflow-auto p-8 relative z-0">
          <div className="max-w-7xl mx-auto pb-12">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
