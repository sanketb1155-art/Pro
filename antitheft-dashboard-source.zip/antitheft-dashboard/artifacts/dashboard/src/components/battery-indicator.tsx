import { Battery, BatteryCharging, BatteryFull, BatteryLow, BatteryMedium, BatteryWarning } from "lucide-react";

interface BatteryIndicatorProps {
  level?: number | null;
  showText?: boolean;
}

export function BatteryIndicator({ level, showText = false }: BatteryIndicatorProps) {
  if (level === undefined || level === null) {
    return (
      <div className="flex items-center gap-1.5 text-muted-foreground text-xs font-mono">
        <Battery className="w-4 h-4 opacity-50" />
        {showText && <span>UNKNOWN</span>}
      </div>
    );
  }

  let Icon = BatteryFull;
  let colorClass = "text-primary";

  if (level > 50) {
    Icon = BatteryFull;
    colorClass = "text-primary";
  } else if (level > 20) {
    Icon = BatteryMedium;
    colorClass = "text-accent";
  } else {
    Icon = BatteryWarning;
    colorClass = "text-destructive animate-pulse";
  }

  return (
    <div className={`flex items-center gap-1.5 text-xs font-mono ${colorClass}`}>
      <Icon className="w-4 h-4" />
      {showText ? <span>{level}%</span> : <span className="text-foreground">{level}%</span>}
    </div>
  );
}
