import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useRegisterDevice, useDeviceHeartbeat, useCreateEvent, useCompleteCommand, getListDevicesQueryKey } from "@workspace/api-client-react";
import { TerminalSquare, Send, CheckCircle2 } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

export default function Simulator() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [deviceId, setDeviceId] = useState("SIM-" + Math.random().toString(36).substring(2, 8).toUpperCase());
  const [cmdId, setCmdId] = useState("");

  const registerDevice = useRegisterDevice({
    mutation: {
      onSuccess: () => {
        toast({ title: "Device Registered", description: "Simulated device successfully connected." });
        queryClient.invalidateQueries({ queryKey: getListDevicesQueryKey() });
      }
    }
  });

  const sendHeartbeat = useDeviceHeartbeat({
    mutation: {
      onSuccess: () => toast({ title: "Heartbeat Sent", description: "Status updated to active." })
    }
  });

  const sendEvent = useCreateEvent({
    mutation: {
      onSuccess: () => toast({ title: "Event Fired", description: "Simulated event transmitted." })
    }
  });

  const completeCommand = useCompleteCommand({
    mutation: {
      onSuccess: () => toast({ title: "Command Completed", description: "Command marked as done." })
    }
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold font-mono text-foreground uppercase tracking-wider">Device Simulator</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
          <CardHeader className="border-b border-border/50">
            <CardTitle className="text-sm font-mono text-muted-foreground uppercase flex items-center gap-2">
              <TerminalSquare className="w-4 h-4 text-primary" /> Core Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-mono text-muted-foreground">Target Device ID</label>
              <div className="flex gap-2">
                <Input 
                  value={deviceId} 
                  onChange={e => setDeviceId(e.target.value)} 
                  className="font-mono bg-background border-border/50" 
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Button 
                variant="outline" 
                className="w-full font-mono text-xs border-border/50 hover:bg-primary/10 hover:text-primary transition-colors"
                onClick={() => registerDevice.mutate({ data: { deviceId, name: "Simulated Device", model: "Pixel 8 Pro", androidVersion: "14", batteryLevel: 85, status: "active", protectionEnabled: true } })}
                disabled={registerDevice.isPending}
              >
                <Send className="w-3 h-3 mr-2" /> Register
              </Button>
              <Button 
                variant="outline" 
                className="w-full font-mono text-xs border-border/50 hover:bg-primary/10 hover:text-primary transition-colors"
                onClick={() => sendHeartbeat.mutate({ data: { deviceId, status: "active", batteryLevel: 84 } })}
                disabled={sendHeartbeat.isPending}
              >
                <Send className="w-3 h-3 mr-2" /> Heartbeat
              </Button>
              <Button 
                variant="outline" 
                className="w-full font-mono text-xs border-border/50 hover:bg-primary/10 hover:text-primary transition-colors"
                onClick={() => sendEvent.mutate({ data: { deviceId, type: "location", latitude: 37.7749, longitude: -122.4194, notes: "Simulated GPS hit" } })}
                disabled={sendEvent.isPending}
              >
                <Send className="w-3 h-3 mr-2" /> Location Event
              </Button>
              <Button 
                variant="outline" 
                className="w-full font-mono text-xs border-border/50 hover:bg-primary/10 hover:text-primary transition-colors"
                onClick={() => sendEvent.mutate({ data: { deviceId, type: "photo", photoUrl: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=", notes: "Simulated camera capture" } })}
                disabled={sendEvent.isPending}
              >
                <Send className="w-3 h-3 mr-2" /> Photo Event
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
          <CardHeader className="border-b border-border/50">
            <CardTitle className="text-sm font-mono text-muted-foreground uppercase flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-accent" /> Command Resolution
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <div className="text-xs font-mono text-muted-foreground mb-4">
              Use this to manually resolve pending commands for simulated devices.
            </div>
            <div className="space-y-2">
              <label className="text-xs font-mono text-muted-foreground">Command ID</label>
              <Input 
                value={cmdId} 
                onChange={e => setCmdId(e.target.value)} 
                placeholder="e.g. 1"
                className="font-mono bg-background border-border/50" 
              />
            </div>
            <Button 
              className="w-full font-mono text-xs bg-accent/20 text-accent border border-accent/30 hover:bg-accent hover:text-accent-foreground"
              onClick={() => completeCommand.mutate({ id: Number(cmdId) })}
              disabled={!cmdId || completeCommand.isPending}
            >
              Mark Command Complete
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}