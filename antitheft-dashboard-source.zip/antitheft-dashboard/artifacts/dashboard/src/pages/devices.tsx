import { useListDevices, getListDevicesQueryKey } from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { format } from "date-fns";
import { BatteryIndicator } from "@/components/battery-indicator";
import { Search, Smartphone, ChevronRight } from "lucide-react";
import { useState } from "react";

export default function DevicesList() {
  const { data: devices, isLoading } = useListDevices(
    { query: { refetchInterval: 10000, queryKey: getListDevicesQueryKey() } }
  );
  const [search, setSearch] = useState("");

  const filteredDevices = devices?.filter(d => 
    d.name.toLowerCase().includes(search.toLowerCase()) || 
    d.model.toLowerCase().includes(search.toLowerCase()) ||
    d.deviceId.toLowerCase().includes(search.toLowerCase())
  ) || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold font-mono text-foreground uppercase tracking-wider">Device Inventory</h1>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input 
          placeholder="Search by name, model, or ID..." 
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-9 font-mono bg-card/50 border-border/50"
        />
      </div>

      <Card className="bg-card/50 border-border/50 backdrop-blur-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-muted-foreground font-mono uppercase bg-muted/20 border-b border-border/50">
              <tr>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Device</th>
                <th className="px-4 py-3">Model</th>
                <th className="px-4 py-3">Battery</th>
                <th className="px-4 py-3">Last Seen</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50 font-mono">
              {isLoading ? (
                <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">Loading devices...</td></tr>
              ) : filteredDevices.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">No devices found.</td></tr>
              ) : (
                filteredDevices.map(device => (
                  <tr key={device.id} className="hover:bg-muted/10 transition-colors group">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${device.status === 'active' ? 'bg-primary shadow-[0_0_8px_var(--color-primary)]' : 'bg-muted-foreground'}`} />
                        <span className={`text-xs ${device.status === 'active' ? 'text-primary' : 'text-muted-foreground'}`}>
                          {device.status.toUpperCase()}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-bold text-foreground">{device.name}</div>
                      <div className="text-xs text-muted-foreground">{device.deviceId.substring(0, 8)}...</div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{device.model}</td>
                    <td className="px-4 py-3">
                      <BatteryIndicator level={device.batteryLevel} />
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {device.lastSeen ? format(new Date(device.lastSeen), 'MMM dd, HH:mm:ss') : 'Never'}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <Link href={`/devices/${device.deviceId}`} className="inline-flex items-center justify-center p-2 rounded hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors opacity-0 group-hover:opacity-100">
                        <ChevronRight className="w-4 h-4" />
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}