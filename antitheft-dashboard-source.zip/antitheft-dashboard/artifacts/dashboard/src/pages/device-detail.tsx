import { useGetDevice, getGetDeviceQueryKey, useListEvents, getListEventsQueryKey, useCreateCommand, useGetPendingCommands, getGetPendingCommandsQueryKey, useListCommands, getListCommandsQueryKey } from "@workspace/api-client-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BatteryIndicator } from "@/components/battery-indicator";
import { EventBadge } from "@/components/event-badge";
import { format } from "date-fns";
import { useLocation, useParams } from "wouter";
import { Camera, Terminal, Shield, Crosshair, ArrowLeft, Clock } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function DeviceDetail() {
  const params = useParams();
  const deviceId = params.deviceId as string;
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: device, isLoading } = useGetDevice(deviceId, {
    query: { enabled: !!deviceId, queryKey: getGetDeviceQueryKey(deviceId), refetchInterval: 10000 }
  });

  const { data: events } = useListEvents({ deviceId, limit: 20 }, {
    query: { enabled: !!deviceId, queryKey: getListEventsQueryKey({ deviceId, limit: 20 }), refetchInterval: 10000 }
  });

  const { data: commands } = useListCommands({ deviceId }, {
    query: { enabled: !!deviceId, queryKey: getListCommandsQueryKey({ deviceId }), refetchInterval: 10000 }
  });

  const createCommand = useCreateCommand({
    mutation: {
      onSuccess: () => {
        toast({ title: "Command issued", description: "Capture photo command sent to device." });
        queryClient.invalidateQueries({ queryKey: getListCommandsQueryKey({ deviceId }) });
        queryClient.invalidateQueries({ queryKey: getGetPendingCommandsQueryKey({ deviceId }) });
      }
    }
  });

  if (isLoading) {
    return <div className="font-mono text-muted-foreground p-8">Establishing secure connection...</div>;
  }

  if (!device) {
    return <div className="font-mono text-destructive p-8">Device not found or connection failed.</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => setLocation("/devices")} className="text-muted-foreground hover:text-foreground">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-bold font-mono text-foreground uppercase tracking-wider flex items-center gap-3">
          {device.name}
          <div className={`px-2 py-0.5 rounded text-xs border ${device.status === 'active' ? 'bg-primary/10 text-primary border-primary/20 shadow-[0_0_10px_rgba(var(--color-primary),0.2)]' : 'bg-muted/50 text-muted-foreground border-border'}`}>
            {device.status.toUpperCase()}
          </div>
        </h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-6">
          <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
            <CardHeader className="pb-2 border-b border-border/50">
              <CardTitle className="text-sm font-mono text-muted-foreground uppercase flex items-center gap-2">
                <Terminal className="w-4 h-4" /> Device Data
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4 font-mono text-sm">
              <div className="flex justify-between items-center border-b border-border/20 pb-2">
                <span className="text-muted-foreground">ID</span>
                <span className="text-foreground text-xs truncate max-w-[150px]">{device.deviceId}</span>
              </div>
              <div className="flex justify-between items-center border-b border-border/20 pb-2">
                <span className="text-muted-foreground">Model</span>
                <span className="text-foreground">{device.model}</span>
              </div>
              <div className="flex justify-between items-center border-b border-border/20 pb-2">
                <span className="text-muted-foreground">OS Version</span>
                <span className="text-foreground">Android {device.androidVersion}</span>
              </div>
              <div className="flex justify-between items-center border-b border-border/20 pb-2">
                <span className="text-muted-foreground">Protection</span>
                <span className={device.protectionEnabled ? "text-primary" : "text-muted-foreground"}>
                  {device.protectionEnabled ? "ENABLED" : "DISABLED"}
                </span>
              </div>
              <div className="flex justify-between items-center border-b border-border/20 pb-2">
                <span className="text-muted-foreground">Battery</span>
                <BatteryIndicator level={device.batteryLevel} showText />
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Last Seen</span>
                <span className="text-foreground text-xs">
                  {device.lastSeen ? format(new Date(device.lastSeen), 'yy/MM/dd HH:mm:ss') : 'N/A'}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
            <CardHeader className="pb-2 border-b border-border/50">
              <CardTitle className="text-sm font-mono text-muted-foreground uppercase flex items-center gap-2">
                <Crosshair className="w-4 h-4" /> Command Center
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
              <Button 
                className="w-full font-mono bg-primary/10 text-primary border border-primary/20 hover:bg-primary hover:text-primary-foreground transition-all"
                onClick={() => createCommand.mutate({ data: { deviceId, type: "capture_photo" } })}
                disabled={createCommand.isPending || device.status === 'offline'}
              >
                <Camera className="w-4 h-4 mr-2" />
                INITIATE PHOTO CAPTURE
              </Button>
              <div className="text-xs font-mono text-muted-foreground text-center">
                {device.status === 'offline' ? 'Device offline. Commands unavailable.' : 'Command will be executed on next heartbeat'}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-2 space-y-6">
          <Card className="bg-card/50 border-border/50 backdrop-blur-sm h-[500px] flex flex-col">
            <CardHeader className="pb-2 border-b border-border/50 shrink-0">
              <CardTitle className="text-sm font-mono text-muted-foreground uppercase flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4" /> Event Log
                </div>
                <div className="text-xs text-primary animate-pulse flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                  MONITORING
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0 flex-1 overflow-auto p-0">
              <div className="divide-y divide-border/50">
                {!events?.length ? (
                  <div className="p-8 text-center text-muted-foreground font-mono text-sm">No events recorded.</div>
                ) : (
                  events.map(event => (
                    <div key={event.id} className="p-4 hover:bg-muted/10 transition-colors flex items-start gap-4">
                      <div className="mt-1">
                        <EventBadge type={event.type} />
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="flex justify-between items-start">
                          <p className="text-sm font-mono text-foreground">
                            {event.notes || `Event: ${event.type.toUpperCase()}`}
                          </p>
                          <span className="text-xs font-mono text-muted-foreground">
                            {format(new Date(event.createdAt), 'yy/MM/dd HH:mm:ss')}
                          </span>
                        </div>
                        {event.type === 'location' && event.latitude && event.longitude && (
                          <div className="mt-2 text-xs font-mono text-muted-foreground bg-muted/30 p-2 rounded border border-border/50">
                            COORDS: {event.latitude.toFixed(6)}, {event.longitude.toFixed(6)}
                          </div>
                        )}
                        {event.type === 'photo' && event.photoUrl && (
                          <div className="mt-3 rounded overflow-hidden border border-border/50 bg-background/50 relative">
                            <img src={event.photoUrl} alt="Captured from device" className="max-h-64 w-auto object-contain" />
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
            <CardHeader className="pb-2 border-b border-border/50">
              <CardTitle className="text-sm font-mono text-muted-foreground uppercase flex items-center gap-2">
                <Clock className="w-4 h-4" /> Command History
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 p-0">
              <div className="divide-y divide-border/50 max-h-48 overflow-auto">
                {!commands?.length ? (
                   <div className="p-4 text-center text-muted-foreground font-mono text-xs">No command history.</div>
                ) : (
                  commands.map(cmd => (
                    <div key={cmd.id} className="p-3 px-4 flex items-center justify-between font-mono text-xs">
                      <div className="flex items-center gap-3">
                        <div className={`w-1.5 h-1.5 rounded-full ${cmd.status === 'completed' ? 'bg-primary' : 'bg-accent'}`} />
                        <span className="text-foreground uppercase">{cmd.type.replace('_', ' ')}</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className={cmd.status === 'completed' ? 'text-primary' : 'text-accent'}>
                          {cmd.status.toUpperCase()}
                        </span>
                        <span className="text-muted-foreground w-32 text-right">
                          {format(new Date(cmd.createdAt), 'HH:mm:ss')}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}