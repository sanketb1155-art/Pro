import { useGetDashboardStats, getGetDashboardStatsQueryKey, useListEvents, getListEventsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, AlertTriangle, Command, Smartphone, RadioTower } from "lucide-react";
import { format } from "date-fns";
import { EventBadge } from "@/components/event-badge";
import { Link } from "wouter";

export default function Dashboard() {
  const { data: stats } = useGetDashboardStats({
    query: { refetchInterval: 10000, queryKey: getGetDashboardStatsQueryKey() }
  });

  const { data: events } = useListEvents(
    { limit: 10 },
    { query: { refetchInterval: 10000, queryKey: getListEventsQueryKey({ limit: 10 }) } }
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold font-mono text-foreground uppercase tracking-wider">System Dashboard</h1>
        <div className="flex items-center gap-2 text-sm font-mono text-muted-foreground">
          <Activity className="w-4 h-4 text-primary animate-pulse" />
          Live Monitoring Active
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-mono text-muted-foreground uppercase">Total Devices</CardTitle>
            <Smartphone className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-mono font-bold text-foreground">{stats?.totalDevices || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">{stats?.activeDevices || 0} currently active</p>
          </CardContent>
        </Card>

        <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-mono text-muted-foreground uppercase">Active Devices</CardTitle>
            <Activity className="w-4 h-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-mono font-bold text-primary">{stats?.activeDevices || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Online devices</p>
          </CardContent>
        </Card>

        <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-mono text-muted-foreground uppercase">Total Events</CardTitle>
            <RadioTower className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-mono font-bold text-foreground">{stats?.totalEvents || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">{stats?.recentEvents || 0} in last 24h</p>
          </CardContent>
        </Card>

        <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-mono text-muted-foreground uppercase">Pending Commands</CardTitle>
            <Command className="w-4 h-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-mono font-bold text-accent">{stats?.pendingCommands || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Awaiting execution</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-lg font-mono font-bold text-foreground uppercase tracking-wider flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-primary" />
            Recent Activity
          </h2>
          <Card className="bg-card/50 border-border/50 backdrop-blur-sm overflow-hidden">
            <div className="divide-y divide-border/50">
              {events?.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground font-mono text-sm">No recent activity detected.</div>
              ) : (
                events?.map(event => (
                  <div key={event.id} className="p-4 hover:bg-muted/20 transition-colors flex items-start gap-4">
                    <div className="mt-1">
                      <EventBadge type={event.type} />
                    </div>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <Link href={`/devices/${event.deviceId}`} className="font-mono text-sm font-bold text-foreground hover:text-primary transition-colors">
                          Device: {event.deviceId.substring(0, 8)}...
                        </Link>
                        <span className="text-xs font-mono text-muted-foreground">
                          {format(new Date(event.createdAt), 'HH:mm:ss')}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {event.notes || `Event triggered: ${event.type}`}
                      </p>
                      {event.type === 'location' && event.latitude && event.longitude && (
                        <p className="text-xs font-mono text-muted-foreground bg-muted/50 inline-block px-2 py-1 rounded">
                          LOC: {event.latitude.toFixed(6)}, {event.longitude.toFixed(6)}
                        </p>
                      )}
                      {event.type === 'photo' && event.photoUrl && (
                        <div className="mt-2 rounded overflow-hidden border border-border/50 bg-background/50 relative aspect-video max-w-sm">
                          <img src={event.photoUrl} alt="Captured" className="object-cover w-full h-full opacity-80 hover:opacity-100 transition-opacity" />
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <h2 className="text-lg font-mono font-bold text-foreground uppercase tracking-wider flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-primary" />
            System Status
          </h2>
          <Card className="bg-card/50 border-border/50 backdrop-blur-sm p-4 space-y-4">
             <div className="flex items-center justify-between">
               <span className="text-sm font-mono text-muted-foreground">API Connection</span>
               <div className="flex items-center gap-2 text-xs font-mono text-primary">
                 <div className="w-2 h-2 rounded-full bg-primary" />
                 SECURE
               </div>
             </div>
             <div className="flex items-center justify-between">
               <span className="text-sm font-mono text-muted-foreground">Encryption</span>
               <div className="flex items-center gap-2 text-xs font-mono text-primary">
                 <div className="w-2 h-2 rounded-full bg-primary" />
                 ACTIVE
               </div>
             </div>
             <div className="flex items-center justify-between">
               <span className="text-sm font-mono text-muted-foreground">Polling Rate</span>
               <span className="text-xs font-mono text-foreground">10s</span>
             </div>
          </Card>
        </div>
      </div>
    </div>
  );
}