import { useListEvents, getListEventsQueryKey } from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EventBadge } from "@/components/event-badge";
import { format } from "date-fns";
import { Link } from "wouter";
import { useState } from "react";
import { Filter } from "lucide-react";

export default function EventsList() {
  const [filterType, setFilterType] = useState<string>("all");

  const queryParams = filterType !== "all" ? { type: filterType } : {};
  
  const { data: events, isLoading } = useListEvents(queryParams, {
    query: { refetchInterval: 10000, queryKey: getListEventsQueryKey(queryParams) }
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold font-mono text-foreground uppercase tracking-wider">Global Event Stream</h1>
        
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-[180px] font-mono text-xs bg-card/50 border-border/50">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">ALL EVENTS</SelectItem>
              <SelectItem value="location">LOCATION</SelectItem>
              <SelectItem value="photo">PHOTO CAPTURE</SelectItem>
              <SelectItem value="unlock">DEVICE UNLOCK</SelectItem>
              <SelectItem value="boot">DEVICE BOOT</SelectItem>
              <SelectItem value="alert">ALERTS</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card className="bg-card/50 border-border/50 backdrop-blur-sm overflow-hidden">
        <div className="divide-y divide-border/50">
          {isLoading ? (
            <div className="p-8 text-center text-muted-foreground font-mono text-sm">Streaming events...</div>
          ) : !events?.length ? (
            <div className="p-8 text-center text-muted-foreground font-mono text-sm">No events matching criteria.</div>
          ) : (
            events.map(event => (
              <div key={event.id} className="p-4 hover:bg-muted/20 transition-colors flex flex-col sm:flex-row gap-4">
                <div className="flex items-start gap-4 flex-1">
                  <div className="mt-1 shrink-0">
                    <EventBadge type={event.type} />
                  </div>
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center justify-between">
                      <Link href={`/devices/${event.deviceId}`} className="font-mono text-sm font-bold text-foreground hover:text-primary transition-colors">
                        {event.deviceId}
                      </Link>
                      <span className="text-xs font-mono text-muted-foreground bg-muted/30 px-2 py-1 rounded">
                        {format(new Date(event.createdAt), 'yyyy-MM-dd HH:mm:ss')}
                      </span>
                    </div>
                    
                    <p className="text-sm font-mono text-muted-foreground uppercase">
                      {event.notes || `SYSTEM: ${event.type} REGISTERED`}
                    </p>
                    
                    {event.type === 'location' && event.latitude && event.longitude && (
                      <div className="inline-flex gap-4 text-xs font-mono bg-background/50 border border-border/50 p-2 rounded">
                        <div><span className="text-muted-foreground">LAT:</span> <span className="text-primary">{event.latitude.toFixed(6)}</span></div>
                        <div><span className="text-muted-foreground">LNG:</span> <span className="text-primary">{event.longitude.toFixed(6)}</span></div>
                      </div>
                    )}
                  </div>
                </div>
                
                {event.type === 'photo' && event.photoUrl && (
                  <div className="shrink-0 rounded border border-border/50 overflow-hidden w-full sm:w-48 aspect-video bg-background/50">
                    <img src={event.photoUrl} alt="Capture" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </Card>
    </div>
  );
}