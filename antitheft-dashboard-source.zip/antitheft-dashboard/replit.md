# Anti-Theft Secure — Admin Dashboard

A real-time admin dashboard for monitoring Android anti-theft protected devices. Receives events from Android phones (selfies on unlock, live GPS location, boot events, alerts) and allows remote commands.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Frontend: React + Vite + TanStack Query + Wouter

## Where things live

- `lib/api-spec/openapi.yaml` — source of truth for all API contracts
- `lib/db/src/schema/devices.ts` — devices table
- `lib/db/src/schema/events.ts` — events table (location, photo, unlock, boot, alert)
- `lib/db/src/schema/commands.ts` — commands table (pending/completed)
- `artifacts/api-server/src/routes/devices.ts` — device registration, heartbeat, stats
- `artifacts/api-server/src/routes/events.ts` — event ingestion and listing
- `artifacts/api-server/src/routes/commands.ts` — command queue management
- `artifacts/dashboard/src/` — React admin dashboard

## Architecture decisions

- Android app sends events via `POST /api/events` (location, photo, unlock, boot, alert)
- Device registration is upsert-based (POST /api/devices creates or updates)
- Heartbeat endpoint (`POST /api/devices/heartbeat`) updates battery + lastSeen
- Commands are polled by the Android device every 30s via `GET /api/commands/pending?deviceId=...`
- Dashboard polls all data every 10 seconds for live feel
- Photo events store base64 data URIs in the photoUrl field

## Product

- Dashboard: real-time stats, recent activity feed, system status
- Devices: list all devices with status, battery, last seen
- Device detail: full event history, battery status, send "Capture Photo" command
- Event Feed: global feed filtered by type with inline photo display
- Simulator: test page to register devices and send events without a real phone

## Android App API endpoints

- `POST /api/devices` — register/update device
- `POST /api/devices/heartbeat` — heartbeat with battery update
- `POST /api/events` — send event (location, photo, unlock, boot, alert)
- `GET /api/commands/pending?deviceId=...` — poll for pending commands
- `PUT /api/commands/:id/complete` — mark command done

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Always run `pnpm run typecheck:libs` after changing `lib/db` schema before typechecking artifacts
- The `photoUrl` field stores full base64 data URIs (`data:image/jpeg;base64,...`) — use directly as `<img src>`
- Device registration is upsert — the Android app calls it on every boot

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
